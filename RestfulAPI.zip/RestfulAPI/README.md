My RESTful api Calculator.hs


How to run

Download the project


'CD' into the directory of the project

`
Run 
$ stack build
` 

now to go execute run the following command

`
$ stack exec Restfulapi
`

This will execute our application

to check to make sure its running go to  "localhost:3000/connect"


If the message 'You are currently successfully connected!' appears then you can start asking questions
For example /add/10/10