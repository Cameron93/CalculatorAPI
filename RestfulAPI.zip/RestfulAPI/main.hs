{-# LANGUAGE OverloadedStrings          #-}
{-# LANGUAGE QuasiQuotes                #-}
{-# LANGUAGE TemplateHaskell            #-}
{-# LANGUAGE TypeFamilies               #-}

import           Prelude                (IO)
import           GHC.Generics
import           ClassyPrelude
import           Yesod



data Calculator = Calculator



mkYesod "Calculator" [parseRoutes|
/connect        ConnectionR GET
/               HomeR GET
/add/#Int/#Int  AdditionR  GET
/sub/#Int/#Int  SubtractionR  GET
/mult/#Int/#Int MultiplicationR GET
/div/#Int/#Int  DivisionR  GET
|]
-- my route handler, passes on the instruction to the appropriate function

instance Yesod Calculator

-- home and connection pages, one to serve as a welcome page, the other to check if im connected

getHomeR :: Handler TypedContent
getHomeR = selectRep $ do
    provideRep $ return
        [shamlet|
            <p style="color:blue;text-align:center:30px;">Hello, welcome to my Calculator.HS	
        |]
		
		
getConnectionR :: Handler TypedContent
getConnectionR = selectRep $ do
    provideRep $ return
        [shamlet|
            <p style="color:blue;text-align:center:30px;">You are currently successfully connected!
        |]
  
-- beneath are all my functions, they rake in the content in the URL and provide a HTML representation as well as a JSON.

getAdditionR :: Int -> Int -> Handler TypedContent
getAdditionR x y = selectRep $ do
    provideRep $ return
        [shamlet|
            <p style="color:blue;text-align:center:30px;">You asked me an addition question, the answer is #{x} + #{y} = #{result}
        |]
    provideJson result 
  where
    result = add x y
	


getSubtractionR :: Int -> Int -> Handler TypedContent
getSubtractionR x y = selectRep $ do
    provideRep $ return
        [shamlet|
            <p style="color:blue;text-align:center:30px;">You asked me a subtraction question, the answer is #{x} - #{y} = #{result}
        |]
    provideJson result
  where
    result = minus x y
	

getMultiplicationR :: Int -> Int -> Handler TypedContent
getMultiplicationR x y = selectRep $ do
    provideRep $ return
        [shamlet|
            <p style="color:blue;text-align:center:30px;">You asked me and multiplication question, the answer is #{x} x #{y} = #{result}
        |]
    provideJson result
  where
    result = multiply x y


getDivisionR :: Int -> Int -> Handler TypedContent
getDivisionR x y = selectRep $ do
    provideRep $ return
        [shamlet|
            <p style="color:blue;text-align:center:140px;">You asked me a division question, the answer is #{x} / #{y} = #{result}
        |]
    provideJson result
  where
    result = divisionCalc x y
	

-- Here are all my calculation functions

add :: Int -> Int -> Int
add x y = x + y

divisionCalc :: Int -> Int -> Float
divisionCalc = (/) `on` fromIntegral 

multiply :: Int -> Int -> Int
multiply x y = x * y

minus :: Int -> Int -> Int
minus x y = x - y	
	


main :: IO ()
main = warp 3000 Calculator
